package bankingmanagement.osdsa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OsdsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
