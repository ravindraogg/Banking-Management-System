package bankingmanagement.osdsa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsdsaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OsdsaApplication.class, args);
	}

}
